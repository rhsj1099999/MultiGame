#pragma once
class CBase
{
	virtual void Release() = 0;
};

