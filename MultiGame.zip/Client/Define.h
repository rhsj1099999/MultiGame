#pragma once

#define			WINCX		800
#define			WINCY		600

#define			PI			3.141592f
#define			PURE		= 0

#define			VK_MAX		0xff

#define			OBJ_NOEVENT 0
#define			OBJ_DEAD	1

extern		HWND	g_hWnd;
extern		HINSTANCE	g_hInstance;
extern		HWND g_hWndEdit;
extern      LONG_PTR g_Proc;