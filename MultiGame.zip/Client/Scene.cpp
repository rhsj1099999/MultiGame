#include "stdafx.h"
#include "Scene.h"

CScene::CScene()
{
}

CScene::~CScene()
{
}

void CScene::SetServerMode(bool bMode)
{
	m_bIsServerMode = bMode;
}
